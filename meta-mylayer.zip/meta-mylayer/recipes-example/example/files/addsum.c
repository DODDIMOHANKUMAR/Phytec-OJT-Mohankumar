#include<stdio.h>

int add()
{
	int a,b,sum;
	printf("Enter the Two numbers");
	scanf("%d%d",&a,&b);
	sum = a+b;
	printf("find out the sum number%d\n",sum);
	return 0;
}
int main()
{
	add();
}
